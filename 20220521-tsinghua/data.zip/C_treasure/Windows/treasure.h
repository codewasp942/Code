#ifndef __TREASURE_H__
#define __TREASURE_H__
#include <vector>
using namespace std;
void Alice(const int, const int, const int, const int, const int[], const int[], bool[]);
int Bob(const int, const int); 
vector<pair<int,bool>> discover(int);
#endif
