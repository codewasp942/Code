if(window.mw)
mw.loader.state({"site":"ready"});
/* cache key: mwiki1-mwiki_zh_:resourceloader:filter:minify-js:7:bd6e88e91c5e8b9c8e1a906e6fa7f64d */